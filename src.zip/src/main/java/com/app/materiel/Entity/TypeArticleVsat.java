package com.app.materiel.Entity;

public enum TypeArticleVsat {
    Parabole,LNB,MODEM_TOOWAY,TPLINK
}
