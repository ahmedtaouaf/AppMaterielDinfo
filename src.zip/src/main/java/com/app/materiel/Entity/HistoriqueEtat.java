package com.app.materiel.Entity;

public enum HistoriqueEtat {
    panne,repare
}
